package dbcrud;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class dbcruddelete {

    public static void main(String[] args) {

        String usuario = "root";
        String password = "1026553655";
        String url = "jdbc:mysql://localhost:3306/dbcrud?useSSL=false&serverTimezone=UTC";


        try (Connection conexion = DriverManager.getConnection(url, usuario, password)) {
            // Cargar el driver de MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Consulta DELETE con parámetros
            String deleteQuery = "DELETE FROM usuario WHERE CEDULA = ?";
            try (PreparedStatement preparedStatement = conexion.prepareStatement(deleteQuery)) {
                preparedStatement.setString(1, "1026553655");
                int rowsAffected = preparedStatement.executeUpdate();

                // Verificar si se eliminó algún registro
                if (rowsAffected > 0) {
                    System.out.println("Registro eliminado correctamente.");
                } else {
                    System.out.println("No se encontró ningún registro con la CEDULA proporcionada.");
                }
            }

            // Mostrar los registros actuales en la tabla
            String selectQuery = "SELECT * FROM usuario";
            try (PreparedStatement selectStatement = conexion.prepareStatement(selectQuery);
                 ResultSet rs = selectStatement.executeQuery()) {

                System.out.println("Registros actuales en la tabla:");
                while (rs.next()) {
                    System.out.println(rs.getString("NOMBRE") + ": " + rs.getString("APELLIDO"));
                }
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(dbcruddelete.class.getName()).log(Level.SEVERE, "Driver no encontrado", ex);
        } catch (SQLException ex) {
            Logger.getLogger(dbcruddelete.class.getName()).log(Level.SEVERE, "Error en la consulta SQL", ex);
        }
    }
}


    
