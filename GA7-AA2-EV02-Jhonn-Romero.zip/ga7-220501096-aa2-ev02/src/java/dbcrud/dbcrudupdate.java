package dbcrud;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class dbcrudupdate {

    public static void main(String[] args) {

        String usuario = "root";
        String password = "1026553655";
        String url = "jdbc:mysql://localhost:3306/dbcrud?useSSL=false&serverTimezone=UTC";

        Connection conexion = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        try {
            // Cargar el driver de MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establecer la conexión
            conexion = DriverManager.getConnection(url, usuario, password);

            // Consulta parametrizada para actualizar datos
            String updateQuery = "UPDATE usuario SET NOMBRE = ?, APELLIDO = ?, CEDULA = ? WHERE id = ?";
            preparedStatement = conexion.prepareStatement(updateQuery);
            preparedStatement.setString(1, "PEDRO");
            preparedStatement.setString(2, "HERNANDEZ");
            preparedStatement.setString(3, "1032888111");
            preparedStatement.setInt(4, 14);

            int rowsAffected = preparedStatement.executeUpdate();
            System.out.println("Filas actualizadas: " + rowsAffected);

            // Ejecutar consulta SELECT para mostrar los resultados
            String selectQuery = "SELECT * FROM usuario";
            preparedStatement = conexion.prepareStatement(selectQuery);
            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                System.out.println(rs.getString("NOMBRE") + ": " + rs.getString("APELLIDO"));
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(dbcrudupdate.class.getName()).log(Level.SEVERE, "Driver no encontrado", ex);
        } catch (SQLException ex) {
            Logger.getLogger(dbcrudupdate.class.getName()).log(Level.SEVERE, "Error en la consulta SQL", ex);
        } finally {
            // Cerrar recursos
            try {
                if (rs != null) rs.close();
                if (preparedStatement != null) preparedStatement.close();
                if (conexion != null) conexion.close();
            } catch (SQLException ex) {
                Logger.getLogger(dbcrudupdate.class.getName()).log(Level.SEVERE, "Error al cerrar recursos", ex);
            }
        }
    }
}


