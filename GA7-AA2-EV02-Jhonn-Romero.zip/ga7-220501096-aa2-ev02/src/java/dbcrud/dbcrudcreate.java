package dbcrud;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class dbcrudcreate {

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/dbcrud?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "1026553655";

    public static void main(String[] args) {
        Connection conexion = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;

        try {
            // Cargar el driver de MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establecer la conexión
            conexion = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD);

            // Crear consulta parametrizada para evitar inyección SQL
            String insertQuery = "INSERT INTO usuario (NOMBRE, APELLIDO, CORREO, CEDULA) VALUES (?, ?, ?, ?)";
            preparedStatement = conexion.prepareStatement(insertQuery);
            preparedStatement.setString(1, "JHONN");
            preparedStatement.setString(2, "PARDO");
            preparedStatement.setString(3, "jhonn@gmail.com");
            preparedStatement.setString(4, "1026553655");
            preparedStatement.executeUpdate();

            System.out.println("Usuario agregado exitosamente.");

            // Consulta para listar todos los registros
            String selectQuery = "SELECT * FROM usuario";
            preparedStatement = conexion.prepareStatement(selectQuery);
            rs = preparedStatement.executeQuery();

            System.out.println("Registros en la tabla usuario:");
            while (rs.next()) {
                System.out.println(rs.getString("NOMBRE") + ": " + rs.getString("APELLIDO"));
            }

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(dbcrudcreate.class.getName()).log(Level.SEVERE, "Driver no encontrado", ex);
        } catch (SQLException ex) {
            Logger.getLogger(dbcrudcreate.class.getName()).log(Level.SEVERE, "Error en la consulta SQL", ex);
        } finally {
            // Cerrar recursos
            try {
                if (rs != null) rs.close();
                if (preparedStatement != null) preparedStatement.close();
                if (conexion != null) conexion.close();
            } catch (SQLException ex) {
                Logger.getLogger(dbcrudcreate.class.getName()).log(Level.SEVERE, "Error al cerrar recursos", ex);
            }
        }
    }
}
