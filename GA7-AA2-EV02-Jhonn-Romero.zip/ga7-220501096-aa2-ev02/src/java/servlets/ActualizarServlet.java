package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "ActualizarServlet", urlPatterns = {"/ActualizarServlet"})
public class ActualizarServlet extends HttpServlet {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/dbcrud?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER = "root"; // Cambia por tu usuario de MySQL
    private static final String DB_PASSWORD = "1026553655"; // Cambia por tu contraseña de MySQL

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String cedula = request.getParameter("cedula");
        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String mensaje;

        if (cedula == null || cedula.trim().isEmpty()) {
            mensaje = "La cédula es obligatoria para actualizar un usuario.";
        } else {
            try {
                // Registrar el driver JDBC
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Establecer la conexión
                try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
                    String sql = "UPDATE usuario SET NOMBRE = ?, APELLIDO = ? WHERE CEDULA = ?";
                    PreparedStatement statement = conn.prepareStatement(sql);
                    statement.setString(1, nombre != null && !nombre.trim().isEmpty() ? nombre : "");
                    statement.setString(2, apellido != null && !apellido.trim().isEmpty() ? apellido : "");
                    statement.setString(3, cedula);
                    int rows = statement.executeUpdate();

                    if (rows > 0) {
                        mensaje = "Usuario actualizado exitosamente.";
                    } else {
                        mensaje = "No se encontró ningún usuario con esa cédula.";
                    }
                }
            } catch (ClassNotFoundException e) {
                // Error si el driver no está disponible
                mensaje = "Error: Driver JDBC no encontrado.";
            } catch (SQLException e) {
                // Otros errores relacionados con la base de datos
                mensaje = "Error al actualizar usuario: " + e.getMessage();
            }
        }

        // Redirigir a la página de resultados con el mensaje
        request.setAttribute("mensaje", mensaje);
        request.getRequestDispatcher("Resultado.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Redirige las solicitudes GET al método POST
        doPost(request, response);
    }
}



