package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "CrearServlet", urlPatterns = {"/CrearServlet"})
public class CrearServlet extends HttpServlet {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/dbcrud?useSSL=false&serverTimezone=UTC";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "1026553655";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String correo = request.getParameter("correo");
        String cedula = request.getParameter("cedula");

        String mensaje;

        // Validar que los campos no estén vacíos
        if (nombre == null || nombre.isEmpty() || 
            apellido == null || apellido.isEmpty() || 
            correo == null || correo.isEmpty() || 
            cedula == null || cedula.isEmpty()) {
            mensaje = "Todos los campos son obligatorios.";
            request.setAttribute("mensaje", mensaje);
            request.getRequestDispatcher("Resultado.jsp").forward(request, response);
            return;
        }

        try {
            // Registrar el driver JDBC
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establecer la conexión
            try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD)) {
                String sql = "INSERT INTO usuario (NOMBRE, APELLIDO, CORREO, CEDULA) VALUES (?, ?, ?, ?)";
                PreparedStatement statement = conn.prepareStatement(sql);
                statement.setString(1, nombre);
                statement.setString(2, apellido);
                statement.setString(3, correo);
                statement.setString(4, cedula);
                statement.executeUpdate();

                mensaje = "Usuario creado exitosamente.";
            }
        } catch (ClassNotFoundException e) {
            // Error si el driver no está disponible
            mensaje = "Error: Driver no encontrado.";
        } catch (SQLException e) {
            // Otros errores relacionados con la base de datos
            mensaje = "Error al crear usuario: " + e.getMessage() + ". Código de error: " + e.getErrorCode();
        }

        // Redirigir a la página de resultados con el mensaje
        request.setAttribute("mensaje", mensaje);
        request.getRequestDispatcher("Resultado.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Redirige las solicitudes GET al método POST
        doPost(request, response);
    }
}


